/* User code: This file will not be overwritten by TASTE. */

#include "signal_handler.h"

void signal_handler_startup()
{
    /* Write your initialization code here,
       but do not make any call to a required interface. */
}

void signal_handler_PI_dummy_trigger()
{
    /* Write your code here! */
}

