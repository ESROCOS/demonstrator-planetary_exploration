/* This file was generated automatically: DO NOT MODIFY IT ! */

/* Declaration of the functions that have to be provided by the user */

#ifndef __USER_CODE_H_signal_handler__
#define __USER_CODE_H_signal_handler__

#ifdef __cplusplus
extern "C" {
#endif

void signal_handler_startup();

void signal_handler_PI_dummy_trigger();

extern void signal_handler_RI_shutdown();

#ifdef __cplusplus
}
#endif


#endif
